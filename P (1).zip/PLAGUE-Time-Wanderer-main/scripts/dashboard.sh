#!/usr/bin/env bash
gh repo view
gh issue list
gh pr list
