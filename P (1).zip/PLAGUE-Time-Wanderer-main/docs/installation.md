1. Download file setup.py
