# PLAGUE: Time Wanderer
## Installation
1. Got to [Releases](https://github.com/Group-of-PLAGUE-Time-Wanderer/PLAGUE-Time-Wanderer/releases) page
2. Download the latest release setup program

**BETA** `🚀 DEV FEATURE`
