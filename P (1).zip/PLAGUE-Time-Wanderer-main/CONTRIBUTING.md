# PLAGUE: Time Wanderer
## Contributing
### Step 1: Fork the repository
First, you need to [create your own copy of PLAGUE: Time Wanderer](https://docs.github.com/en/get-started/quickstart/fork-a-repo).
### Step 2: Code !
Fixing a bug, linting code, addinga functionality ? Just code !
### Step 3: Create Pull Request
After, you need to [create a pull request from your fork](https://docs.github.com/en/github/collaborating-with-pull-requests/proposing-changes-to-your-work-with-pull-requests/creating-a-pull-request-from-a-fork). Follow the template !
### Step 4: Thanks for contribute !
Thanks !
